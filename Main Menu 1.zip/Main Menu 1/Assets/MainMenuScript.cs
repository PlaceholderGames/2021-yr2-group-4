﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class MainMenuScript : MonoBehaviour
{
    public void PlayTheGame()
    {
        SceneManager.LoadScene("MAINMENU");
    }
       
    public void QUIT()
    {
        Debug.Log("QUIT");
        Application.Quit();
    }
}
